# Notification Hub reference

Base URL comes from `NOTIFY_API_URL`; authentication comes from `NOTIFY_API_TOKEN`.

| User level | API level | Visible marker | Schedule | End state |
|---|---:|---|---|---|
| A / red | 1 | 🔴 | 0m WeCom ×3; 1m email; 2m ServerChan; 3/6/9/12/15/18m all | Confirmed or lost at 20m |
| B / yellow | 2 | 🟡 | 0m WeCom; 5m email; 10m ServerChan; 15/20/25m all | Confirmed or lost at 30m |
| C / WeCom | 3 | 🟢 | WeCom once | Informational; no confirmation |
| D / email | 4 | 🟢 | Email once | Informational; no confirmation |
| E / ServerChan | 5 | 🟢 | ServerChan once | Informational; no confirmation |

Submit a business title; the deployed service normalizes delivery to exactly one correct colored circle. Do not add visible level words. The first body line should hold the core result for email previews; add concrete detail after a blank line when needed.

Delivered titles include `[source]`; use a recognizable project name. Delete an event with `notification_client.py delete --id EVENT_ID`.

Event uniqueness is `source + eventKey`. Reusing an open event updates content without duplicating its delivery plan. Confirmed or lost events require a new event key.

Event statuses: `open`, `confirmed`, `lost`, `informational`. Delivery statuses: `pending`, `sending`, `sent`, `failed`, `cancelled`.
