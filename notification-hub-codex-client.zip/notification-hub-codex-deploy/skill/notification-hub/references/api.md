# Notification Hub reference

Base URL comes from `NOTIFY_API_URL`; authentication comes from `NOTIFY_API_TOKEN`.

| User level | API level | Visible marker | Schedule | End state |
|---|---:|---|---|---|
| A / red | 1 | 🔴 | 0m WeCom ×3 + Weixin; 1m email; 2m ServerChan; 3/6/9/12/15/18m all | Confirmed or lost at 20m |
| B / yellow | 2 | 🟡 | 0m WeCom; 5m email; 10m ServerChan; 15/20/25m WeCom/email/ServerChan | Confirmed or lost at 30m |
| C / WeCom | 3 | 🟢 | WeCom once | Informational; no confirmation |
| D / email | 4 | 🟢 | Email once | Informational; no confirmation |
| E / ServerChan | 5 | 🟢 | ServerChan once | Informational; no confirmation |

Submit a business title; the deployed service normalizes delivery to exactly one correct colored circle. Do not add visible level words. The first body line should hold the core result for email previews; add concrete detail after a blank line when needed.

Delivered titles include `[source]`; use a recognizable project name. Delete an event with `notification_client.py delete --id EVENT_ID`.

The client sends `device` automatically from the computer hostname; override it with `--device` or `NOTIFY_DEVICE_NAME` only when a stable friendly name is preferred.

Event uniqueness is `source + eventKey`. Reusing an open event updates content without duplicating its delivery plan. Confirmed or lost events require a new event key.

Event statuses: `open`, `confirmed`, `lost`, `informational`. Delivery statuses: `pending`, `sending`, `sent`, `failed`, `cancelled`.

Bug-fix requests carry `projectPath`, `plan`, and `impactFiles`. Approval lasts 30 minutes; approved work waits for the originating device. Worker states are `approved`, `running`, `succeeded`, `failed`, `timed_out`, and rollback states.

B enables WeCom, email, and ServerChan by default. A caller may pass exactly one `disabledChannel` (`wecom`, `email`, or `serverchan`); the service omits that channel's initial delivery and every retry. Weixin is independent from B and is not a valid B channel switch. A and C–E reject this option.

For a one-time personal-WeChat message without confirmation, add `--channel weixin` to C, D, or E. Without this selector, C/D/E keep their existing dedicated defaults.

## Personal-Weixin inbound boundary

The server persists bound-user text in an AES-GCM encrypted outbox before advancing the iLink cursor. Assistant Gateway uses a distinct service token with `POST /v1/weixin-inbound/claim` and `POST /v1/weixin-inbound/:id/ack`; normal notification clients do not consume these routes. Claim returns a bounded lease plus transport/sender metadata; ack supports `processed`, `retry`, and `dead_letter`. Notification Hub does not parse approvals or write HQ/TaskBox.

Assistant Gateway may reply during a valid lease through `POST /v1/weixin-inbound/:id/reply` with `consumerId`, `leaseToken`, stable `replyKey`, and 1–2000 character `text`. Hub derives the bound recipient and conversation context from the inbound record; callers cannot provide a target. `(inbound id, replyKey)` is idempotent for identical text and conflicts on changed text. Reply uses only the ingress token and grants no HQ/TaskBox authority.
