---
name: notification-hub
description: Send and query single-recipient notifications through the deployed five-level Notification Hub. Use when the user asks to notify, remind, send, or dispatch with “通知中枢”, A/B/C/D/E level, strong reminders, WeCom, email, or ServerChan, or asks for delivery status. A/B escalate; C sends WeCom once; D sends email once; E sends ServerChan once.
---

# Notification Hub

Use `scripts/notification_client.py` for every operation. Do not handcraft HTTP requests or expose credentials.

## Send

1. Send only when the user uses an explicit action verb such as “通知、提醒、发送、推送”. Discussion about notification design does not send.
2. Map levels deterministically:
   - `A / 红色 / 最高级 / 一级 / 强提醒` → `1` → visible prefix `🔴`
   - `B / 黄色 / 次级 / 二级 / 行动提醒` → `2` → visible prefix `🟡`
   - `C / 企微通知` → `3` → WeCom once → visible prefix `🟢`
   - `D / 邮件通知` → `4` → email once → visible prefix `🟢`
   - `E / Server酱通知` → `5` → ServerChan once → visible prefix `🟢`
   - Weixin is an independent channel: level A includes it in its strong escalation policy, level B never sends or retries it, and an explicit informational request may use C–E with `--channel weixin` for one-time delivery.
   Never add visible text such as `一级`, `二级`, `三级`, `强提醒`, `普通信息`, `红色提醒`, `黄色提醒`, or `绿色提醒`; the colored circle alone communicates the level.
3. Derive `source` from the current project or system name; use `codex` only when no source exists.
4. Create a concise title and complete body from the request without inventing business facts.
5. Generate one stable event key and reuse it on retries.
6. Run:

```powershell
python scripts/notification_client.py send --source SOURCE --event-key EVENT_KEY --level A --title TITLE --body BODY
```

For one-time personal-WeChat robot delivery:

```powershell
python scripts/notification_client.py send --source SOURCE --event-key EVENT_KEY --level C --channel weixin --title TITLE --body BODY
```

An explicit request to send through A/B/C/D/E authorizes the corresponding external notification; execute directly. Return the event ID, normalized level, status, and confirmation URL when present.

For B only, WeCom, email, and ServerChan are enabled by default. If the user explicitly closes exactly one channel, add one of `--disabled-channel wecom`, `--disabled-channel email`, or `--disabled-channel serverchan`. That channel and all of its scheduled retries are omitted. Weixin is independent from B and is not a valid B switch. A always uses all four channels; never apply this option to A/C/D/E.

## Bug-fix approval

When a notification reports a concrete software defect and asks the user to approve automatic repair, include the approved proposal rather than embedding shell commands:

```powershell
python scripts/notification_client.py send --source SOURCE --event-key EVENT_KEY --level B --title TITLE --body BODY --bug-fix-plan PLAN --project-path PROJECT_PATH --impact-file FILE
```

The client adds the sending computer automatically. Use one `--impact-file` per predicted file. The dashboard approval expires after 30 minutes; once approved, `bugfix_worker.py` waits for that exact computer, creates a new Codex task, and reports execution status. Never claim approval or execution before the API returns it.

## Query

```powershell
python scripts/notification_client.py list --limit 100
python scripts/notification_client.py health
python scripts/notification_client.py delete --id EVENT_ID
```

Summarize stable JSON output. For failed commands, report the returned error code and reuse the same event key when retrying.

Read `references/api.md` only when exact schedules, statuses, or response fields are needed.

The personal-Weixin inbound outbox is a service-to-service boundary for Assistant Gateway, not an ordinary notification operation. Do not claim or acknowledge inbound messages through this skill unless explicitly operating that Gateway integration; Notification Hub never interprets approval text or writes HQ/TaskBox.
