#!/usr/bin/env python3
import argparse
import datetime as dt
import json
import os
import pathlib
import socket
import subprocess
import sys
import urllib.error
import urllib.request
import uuid

LEVELS = {"A": 1, "1": 1, "CRITICAL": 1, "B": 2, "2": 2, "ACTION": 2, "C": 3, "3": 3, "WECOM": 3, "D": 4, "4": 4, "EMAIL": 4, "E": 5, "5": 5, "SERVERCHAN": 5}
CONFIG_PATH = pathlib.Path.home() / ".config" / "notification-hub" / "config.json"


class ClientError(Exception):
    def __init__(self, code, message, status=None):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


def user_environment(name):
    value = os.environ.get(name)
    if value:
        return value
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
                return winreg.QueryValueEx(key, name)[0]
        except (FileNotFoundError, OSError):
            pass
    return None


def file_configuration():
    try:
        value = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (FileNotFoundError, OSError, json.JSONDecodeError):
        return {}


def configuration(require_token=True):
    saved = file_configuration()
    base_url = (user_environment("NOTIFY_API_URL") or saved.get("NOTIFY_API_URL") or "https://liangzai666.com/notify/api").rstrip("/")
    token = saved.get("NOTIFY_API_TOKEN") or user_environment("NOTIFY_API_TOKEN") or "282426"
    if require_token and not token:
        raise ClientError("CONFIG_MISSING", "NOTIFY_API_TOKEN is not configured")
    return base_url, token


def request(method, path, payload=None, require_token=True):
    base_url, token = configuration(require_token)
    headers = {"accept": "application/json", "user-agent": "notification-hub-skill/1.0"}
    if token:
        headers["authorization"] = f"Bearer {token}"
    body = None
    if payload is not None:
        headers["content-type"] = "application/json; charset=utf-8"
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(f"{base_url}{path}", data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=25) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        try:
            detail = json.loads(error.read().decode("utf-8")).get("error", {})
            raise ClientError(detail.get("code", f"HTTP_{error.code}"), detail.get("message") or error.reason, error.code)
        except json.JSONDecodeError:
            raise ClientError(f"HTTP_{error.code}", str(error.reason), error.code)
    except (urllib.error.URLError, TimeoutError) as error:
        raise ClientError("NETWORK_ERROR", str(getattr(error, "reason", error)))


def normalize_level(value):
    level = LEVELS.get(str(value).strip().upper())
    if not level:
        raise ClientError("INVALID_LEVEL", "level must be A, B, C, D, E, or 1-5")
    return level


def default_source():
    return pathlib.Path.cwd().name.strip() or "codex"


def default_device():
    configured = user_environment("NOTIFY_DEVICE_NAME")
    if configured:
        return configured.strip()
    if os.name == "nt" and os.environ.get("COMPUTERNAME"):
        return os.environ["COMPUTERNAME"].strip()
    if sys.platform == "darwin":
        for key in ("ComputerName", "LocalHostName"):
            result = subprocess.run(["scutil", "--get", key], text=True, capture_output=True)
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
    return socket.gethostname().strip() or "未知设备"


def default_event_key(source):
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d%H%M%S")
    return f"{source}:{stamp}:{uuid.uuid4().hex[:8]}"


def send(args):
    source = args.source or default_source()
    payload = {
        "source": source,
        "device": args.device or default_device(),
        "eventKey": args.event_key or default_event_key(source),
        "level": normalize_level(args.level),
        "title": args.title,
        "body": args.body,
    }
    if args.bug_fix_plan:
        payload["bugFix"] = {"projectPath": str(pathlib.Path(args.project_path or pathlib.Path.cwd()).resolve()), "plan": args.bug_fix_plan, "impactFiles": args.impact_file or []}
    result = request("POST", "/v1/events", payload)
    return {"ok": True, "operation": "send", "created": result.get("created"), "event": result.get("event"), "confirmationUrl": result.get("confirmationUrl")}


def list_events(args):
    result = request("GET", f"/v1/events?limit={max(1, min(args.limit, 500))}")
    return {"ok": True, "operation": "list", "events": result.get("events", [])}


def health(_args):
    return {"ok": True, "operation": "health", **request("GET", "/v1/health", require_token=False)}


def delete_event(args):
    result = request("DELETE", f"/v1/events/{args.id}")
    return {"ok": True, "operation": "delete", **result}


def build_parser():
    root = argparse.ArgumentParser(description="Deterministic client for Notification Hub")
    commands = root.add_subparsers(dest="command", required=True)
    send_parser = commands.add_parser("send")
    send_parser.add_argument("--source")
    send_parser.add_argument("--device")
    send_parser.add_argument("--event-key")
    send_parser.add_argument("--level", required=True)
    send_parser.add_argument("--title", required=True)
    send_parser.add_argument("--body", required=True)
    send_parser.add_argument("--bug-fix-plan")
    send_parser.add_argument("--project-path")
    send_parser.add_argument("--impact-file", action="append")
    send_parser.set_defaults(handler=send)
    list_parser = commands.add_parser("list")
    list_parser.add_argument("--limit", type=int, default=100)
    list_parser.set_defaults(handler=list_events)
    health_parser = commands.add_parser("health")
    health_parser.set_defaults(handler=health)
    delete_parser = commands.add_parser("delete")
    delete_parser.add_argument("--id", required=True)
    delete_parser.set_defaults(handler=delete_event)
    return root


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    try:
        args = build_parser().parse_args()
        print(json.dumps(args.handler(args), ensure_ascii=False, separators=(",", ":")))
        return 0
    except ClientError as error:
        print(json.dumps({"ok": False, "error": {"code": error.code, "message": error.message, "status": error.status}}, ensure_ascii=False, separators=(",", ":")))
        return 1
    except Exception as error:
        print(json.dumps({"ok": False, "error": {"code": "CLIENT_ERROR", "message": str(error)}}, ensure_ascii=False, separators=(",", ":")))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
