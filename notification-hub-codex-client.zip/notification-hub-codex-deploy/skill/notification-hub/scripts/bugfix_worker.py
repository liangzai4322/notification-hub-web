#!/usr/bin/env python3
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time
import urllib.parse

from notification_client import ClientError, default_device, request

STATE_DIR = pathlib.Path.home() / ".local" / "share" / "notification-hub"
LOCK = STATE_DIR / "bugfix-worker.lock"
POLL_SECONDS = 60
TIMEOUT_SECONDS = 60 * 60


def command(args, cwd, timeout=120, check=True):
    result = subprocess.run(args, cwd=cwd, text=True, capture_output=True, encoding="utf-8", errors="replace", timeout=timeout)
    output = (result.stdout + result.stderr).strip()
    if check and result.returncode:
        raise RuntimeError(f"{' '.join(args)}\n{output}")
    return result.returncode, output


def acquire_lock():
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    if LOCK.exists() and time.time() - LOCK.stat().st_mtime < POLL_SECONDS * 3:
        return False
    LOCK.write_text(str(os.getpid()), encoding="utf-8")
    return True


def touch_lock():
    LOCK.touch(exist_ok=True)


def safe_files(project, values):
    root = project.resolve()
    files = []
    for value in values:
        candidate = (root / value).resolve()
        if candidate == root or root not in candidate.parents:
            raise RuntimeError(f"影响文件超出项目目录: {value}")
        files.append((value, candidate))
    return files


def backup_files(job, project):
    backup = STATE_DIR / "backups" / job["id"]
    backup.mkdir(parents=True, exist_ok=True)
    manifest = []
    for relative, source in safe_files(project, job.get("impactFiles") or []):
        target = backup / "files" / relative
        existed = source.is_file()
        if existed:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        manifest.append({"path": relative, "existed": existed})
    (backup / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return backup


def rollback(job):
    project = pathlib.Path(job["projectPath"]).expanduser().resolve()
    backup = pathlib.Path(job.get("backupPath") or "")
    manifest = json.loads((backup / "manifest.json").read_text(encoding="utf-8"))
    for item in manifest:
        destination = (project / item["path"]).resolve()
        if item["existed"]:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(backup / "files" / item["path"], destination)
        elif destination.exists():
            destination.unlink()
    return {"status": "rolled_back", "backupPath": str(backup), "resultSummary": "已恢复修复前备份文件"}


def extract_task_id(log):
    for line in log.splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        stack = [value]
        while stack:
            item = stack.pop()
            if isinstance(item, dict):
                for key in ("thread_id", "threadId"):
                    if item.get(key):
                        return str(item[key])
                stack.extend(item.values())
            elif isinstance(item, list):
                stack.extend(item)
    return None


def run_codex(job, project, git_project):
    prompt = f"""你正在执行一项已由用户在通知中枢批准的 Bug 修复任务。
问题：{job.get('eventTitle') or ''}
详情：{job.get('eventBody') or ''}
批准方案：{job['plan']}
预计影响文件：{', '.join(job.get('impactFiles') or []) or '由你确认'}

要求：先检查根因，再做最小修复；运行适用测试；不要提交、推送或创建 PR（外层执行器负责）；不要修改与该问题无关的文件；最后简洁汇报改动与验证结果。"""
    args = ["codex", "exec", "--json", "-C", str(project), "-s", "workspace-write", "-a", "never"]
    if not git_project:
        args.append("--skip-git-repo-check")
    args.append(prompt)
    process = subprocess.Popen(args, cwd=project, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, encoding="utf-8", errors="replace")
    try:
        output, _ = process.communicate(timeout=TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        process.kill()
        output, _ = process.communicate()
        return "timed_out", output, extract_task_id(output)
    return ("succeeded" if process.returncode == 0 else "failed"), output, extract_task_id(output)


def execute(job):
    project = pathlib.Path(job["projectPath"]).expanduser().resolve()
    if not project.is_dir():
        raise RuntimeError(f"项目目录不存在: {project}")
    git_project = command(["git", "rev-parse", "--is-inside-work-tree"], project, check=False)[0] == 0
    backup = None
    branch = commit_sha = pr_url = None
    if git_project:
        if command(["git", "status", "--porcelain"], project)[1]:
            raise RuntimeError("Git工作区存在未提交修改，已停止以避免混入自动修复")
        branch = f"bugfix/{job['id'][:8]}"
        command(["git", "switch", "-c", branch], project)
    else:
        if not job.get("impactFiles"):
            raise RuntimeError("非Git项目必须在审批方案中声明影响文件，已停止以保证可回滚")
        backup = backup_files(job, project)
    status, log, task_id = run_codex(job, project, git_project)
    if status != "succeeded":
        return {"status": status, "taskId": task_id, "backupPath": str(backup) if backup else None, "log": log, "resultSummary": "Codex修复未完成，请查看执行日志"}
    if git_project:
        if not command(["git", "status", "--porcelain"], project)[1]:
            raise RuntimeError("Codex执行成功但没有产生文件修改")
        command(["git", "add", "-A"], project)
        command(["git", "commit", "-m", f"fix: {job.get('eventTitle') or 'approved bug fix'}"], project)
        commit_sha = command(["git", "rev-parse", "HEAD"], project)[1]
        command(["git", "push", "-u", "origin", branch], project, timeout=300)
        pr_url = command(["gh", "pr", "create", "--fill", "--head", branch], project, timeout=300)[1].splitlines()[-1]
    return {"status": "succeeded", "taskId": task_id, "branch": branch, "commitSha": commit_sha, "prUrl": pr_url,
            "backupPath": str(backup) if backup else None, "log": log, "resultSummary": "自动修复与验证已完成"}


def process_one(device):
    job = request("GET", f"/v1/bug-fixes/next?device={urllib.parse.quote(device)}").get("job")
    if not job:
        return False
    claimed = request("POST", f"/v1/bug-fixes/{job['id']}/claim", {"device": device}).get("job")
    if not claimed:
        return False
    try:
        report = rollback(claimed) if claimed["status"] == "rollback_requested" else execute(claimed)
    except subprocess.TimeoutExpired as error:
        report = {"status": "timed_out", "log": str(error), "resultSummary": "外部命令执行超时"}
    except Exception as error:
        report = {"status": "rollback_failed" if claimed["status"] == "rollback_requested" else "failed", "log": str(error), "resultSummary": str(error)}
    request("POST", f"/v1/bug-fixes/{job['id']}/report", report)
    return True


def main():
    if not acquire_lock():
        return 0
    device = default_device()
    try:
        while True:
            touch_lock()
            try:
                while process_one(device):
                    touch_lock()
            except ClientError:
                pass
            time.sleep(POLL_SECONDS)
    finally:
        LOCK.unlink(missing_ok=True)


if __name__ == "__main__":
    raise SystemExit(main())
