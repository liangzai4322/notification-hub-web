# 五级通知系统：Codex 快速部署说明

## 目标

把本包交给另一台电脑上的 Codex，让它安装 `notification-hub` Skill。安装后可直接说：

- `用三级通知 A 提醒我处理服务器故障`
- `用三级通知 B 通知我跟进客户`
- `用 C 级通过企业微信通知我`
- `用 D 级通过邮件通知我`
- `用 E 级通过 Server酱通知我`
- `查询通知中枢最近状态`

## 直接交给 Codex 的指令

> 解压此包，阅读《给Codex的部署说明.md》，运行 `python3 install.py`（Windows 可用 `py install.py`）。安装时让我输入 NOTIFY_API_TOKEN，不要在输出、代码、日志或聊天中显示 Token。安装后执行 health 检查并告诉我结果。

## 安装步骤

1. 解压 ZIP。
2. 在解压目录运行：

   - macOS / Linux：`python3 install.py`
   - Windows：`py install.py`

3. Token 已统一为 `282426`，无需单独查找。
4. 看到 `"ok":true` 和 `installed_skill=...` 即成功。
5. 重启 Codex，使新 Skill 被发现。

安装器只保存两项：

- Skill：`$CODEX_HOME/skills/notification-hub`，默认 `~/.codex/skills/notification-hub`
- 私密配置：`~/.config/notification-hub/config.json`，macOS/Linux 权限为 `600`

包内不含 Token、邮箱密码、企微 Webhook、Server酱 SendKey 或服务器密码；其他电脑只调用已部署的 HTTPS API，因此无需配置这些渠道密钥。

## 验证

安装后先执行只读检查：

```bash
python3 ~/.codex/skills/notification-hub/scripts/notification_client.py health
```

Windows PowerShell：

```powershell
py "$HOME/.codex/skills/notification-hub/scripts/notification_client.py" health
```

然后在 Codex 中明确要求发送一条 C、D 或 E 级测试通知：C = 企业微信，D = 邮件，E = Server酱。A/B 会启动升级与确认流程，不用于普通安装测试。

## 更新与卸载

- 更新：使用新版包重新运行安装器，会替换 Skill，保留并重写私密配置。
- 在线更新：运行 `python3 ~/.config/notification-hub/install.py --update`；Windows 使用 `py "$HOME/.config/notification-hub/install.py" --update`。
- 更新优先从 GitHub Contents API 拉取（避免 Raw CDN 旧缓存），失败后自动切换云服务器，两个来源保存同一发布包。
- 卸载：删除 Skill 目录和 `~/.config/notification-hub/config.json`。
- Token 泄露：立即在服务端更换 Token，再重新运行安装器。

## 常见错误

- `CONFIG_MISSING`：未写入 Token，重新运行安装器。
- `UNAUTHORIZED`：Token 错误或已轮换。
- `NETWORK_ERROR`：检查目标电脑是否能访问 `https://liangzai666.com/notify/api/v1/health`。
- Codex 不触发 Skill：重启 Codex，并确认 Skill 位于正确的 `$CODEX_HOME/skills` 下。
