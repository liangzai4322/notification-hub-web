#!/usr/bin/env python3
import argparse
import getpass
import json
import os
import pathlib
import plistlib
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile


ROOT = pathlib.Path(__file__).resolve().parent
SOURCE_SKILL = ROOT / "skill" / "notification-hub"
DEFAULT_TOKEN = "282426"
DOWNLOAD_URLS = (
    "https://api.github.com/repos/liangzai4322/notification-hub-web/contents/notification-hub-codex-client.zip",
    "https://liangzai666.com/notify/api/v1/client-package",
)


def parse_args():
    parser = argparse.ArgumentParser(description="Install Notification Hub skill for Codex")
    parser.add_argument("--codex-home", help="Codex home; defaults to CODEX_HOME or ~/.codex")
    parser.add_argument("--api-url", default="https://liangzai666.com/notify/api")
    parser.add_argument("--token", default=DEFAULT_TOKEN)
    parser.add_argument("--update", action="store_true", help="Download latest package from GitHub, then server fallback")
    parser.add_argument("--skip-health", action="store_true")
    parser.add_argument("--no-worker", action="store_true", help="Do not install the background bug-fix worker")
    return parser.parse_args()


def main():
    args = parse_args()
    if args.update:
        update(args)
        return
    codex_home = pathlib.Path(args.codex_home or os.environ.get("CODEX_HOME") or pathlib.Path.home() / ".codex").expanduser()
    destination = codex_home / "skills" / "notification-hub"
    token = args.token or os.environ.get("NOTIFY_API_TOKEN") or getpass.getpass("NOTIFY_API_TOKEN（输入不回显）: ").strip()
    if not token:
        raise SystemExit("NOTIFY_API_TOKEN 不能为空")

    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        shutil.rmtree(destination)
    shutil.copytree(SOURCE_SKILL, destination)

    config_path = pathlib.Path.home() / ".config" / "notification-hub" / "config.json"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps({
        "NOTIFY_API_URL": args.api_url.rstrip("/"),
        "NOTIFY_API_TOKEN": token,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    shutil.copy2(__file__, config_path.parent / "install.py")
    try:
        os.chmod(config_path, 0o600)
    except OSError:
        pass

    if not args.no_worker:
        install_worker(destination)

    if not args.skip_health:
        result = subprocess.run(
            [sys.executable, str(destination / "scripts" / "notification_client.py"), "health"],
            text=True,
            capture_output=True,
            encoding="utf-8",
        )
        if result.returncode != 0:
            print(result.stdout or result.stderr, file=sys.stderr)
            raise SystemExit("Skill 已安装，但健康检查失败")
        print(result.stdout.strip())
        auth = subprocess.run(
            [sys.executable, str(destination / "scripts" / "notification_client.py"), "list", "--limit", "1"],
            text=True, capture_output=True, encoding="utf-8",
        )
        if auth.returncode != 0:
            raise SystemExit("Skill 已安装，但 API Token 鉴权失败")

    print(f"installed_skill={destination}")
    print(f"private_config={config_path}")
    print("请重启 Codex，然后说：用 C 级通过企业微信发送一条测试通知")


def install_worker(skill_directory):
    worker = skill_directory / "scripts" / "bugfix_worker.py"
    if sys.platform == "darwin":
        label = "com.notification-hub.bugfix-worker"
        agents = pathlib.Path.home() / "Library" / "LaunchAgents"
        agents.mkdir(parents=True, exist_ok=True)
        plist = agents / f"{label}.plist"
        log_dir = pathlib.Path.home() / "Library" / "Logs" / "notification-hub"
        log_dir.mkdir(parents=True, exist_ok=True)
        plist.write_bytes(plistlib.dumps({"Label": label, "ProgramArguments": [sys.executable, str(worker)], "RunAtLoad": True,
            "KeepAlive": True, "StandardOutPath": str(log_dir / "worker.log"), "StandardErrorPath": str(log_dir / "worker-error.log")}))
        domain = f"gui/{os.getuid()}"
        subprocess.run(["launchctl", "bootout", domain, str(plist)], capture_output=True)
        subprocess.run(["launchctl", "bootstrap", domain, str(plist)], check=True)
    elif os.name == "nt":
        task = "NotificationHubBugfixWorker"
        command = f'"{sys.executable}" "{worker}"'
        subprocess.run(["schtasks", "/Create", "/F", "/SC", "ONLOGON", "/TN", task, "/TR", command], check=True, capture_output=True)
        subprocess.run(["schtasks", "/Run", "/TN", task], check=True, capture_output=True)
    else:
        print("worker_install=manual (run bugfix_worker.py at login)")


def update(args):
    error = None
    for url in DOWNLOAD_URLS:
        with tempfile.TemporaryDirectory(prefix="notification-hub-update-") as directory:
            archive = pathlib.Path(directory) / "client.zip"
            try:
                request = urllib.request.Request(url, headers={"Accept": "application/vnd.github.raw+json", "User-Agent": "notification-hub-updater/1"})
                with urllib.request.urlopen(request, timeout=30) as response:
                    archive.write_bytes(response.read())
                with zipfile.ZipFile(archive) as bundle:
                    bundle.testzip()
                    bundle.extractall(directory)
                package = pathlib.Path(directory) / "notification-hub-codex-deploy"
                command = [sys.executable, str(package / "install.py"), "--token", args.token, "--api-url", args.api_url]
                if args.codex_home: command.extend(["--codex-home", args.codex_home])
                if args.skip_health: command.append("--skip-health")
                if args.no_worker: command.append("--no-worker")
                subprocess.run(command, check=True)
                print(f"updated_from={url}")
                return
            except Exception as exc:
                error = exc
    raise SystemExit(f"GitHub 和服务器更新源均失败: {error}")


if __name__ == "__main__":
    main()
